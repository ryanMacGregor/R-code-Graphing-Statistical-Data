# Dataset: diffusingCapacity.csv

diffusingCapacity = read.csv(file.choose(), header = T)
names(diffusingCapacity)
fix(diffusingCapacity)
attach(diffusingCapacity)

model = lm(y ~ 1)
model

##########################################################
# Two sided alternative:
# H_{0} = 90 vs H_{a} \neq 90.
t.test(y, alternative = "two.sided", mu = 90, conf.level=0.95)
##########################################################


##########################################################
# Left sided alternative:
# H_{0} = 100 vs H_{a} < 100.
t.test(y, alternative = "less", mu = 100, conf.level=0.99)
#--------------------------------------------------------
# Manual Calculation of p-value:
#--------------------------------------------------------
alpha = 0.01 # Level of Significance!
n = length(y)
s = sd(y)
muHat = mean(y)
mu0 = 100
testStat = (muHat - mu0)/(s/sqrt(n))

# 99% Lower CI:
c(-Inf,muHat+qt(1-alpha,n-1)*s/sqrt(n))

p_val = pt(testStat,n-1)
##########################################################

##########################################################
# Right sided alternative:
# H_{0} = 100 vs H_{a} > 80.
t.test(y, alternative = "greater", mu = 80, conf.level=0.98)
#--------------------------------------------------------

detach(diffusingCapacity)
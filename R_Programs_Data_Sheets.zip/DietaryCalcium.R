# Worksheet for Hypothesis Test
# Dietary Calcium

DC = c(886,633,943,847,934,841,
       1193,820,774,834,1050,1058,
       1192,975,1313,872,1079,809)

n = length(DC)
n
m = mean(DC)
m
s = sd(DC)
s

# For z-test:
sigma = 188

z = (m-1000)/(188/sqrt(n))

# For t-test:
t.test(DC,mu=1000, alternative="less",conf.level=0.95)

detach(DietaryCalcium)

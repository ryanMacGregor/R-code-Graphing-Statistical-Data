# This program computes the confidence intervals of linear
# model for the dataset "Stearic Acid and Digestibility of Fat"
# Dataset: acidDigest.csv

acidDigest = read.csv(file.choose(), header=T)
attach(acidDigest)
fix(acidDigest)
summary(acidDigest)

plot(x,y) 

dim(acidDigest)

# Lixnear Model -- lm()
model = lm(y ~ x)
summary(model)

# How well does the linear model fit?
cor(x, y)

#############################################################
# Confidence Intervals: Manual Calculations:
n = length(x)
yHat = predict(model) 
SSe = sum((y-yHat)^2)
SSx = sum((x-mean(x))^2)
s = sqrt(SSe/(n-2))
SEa = s*sqrt((1/n)+((mean(x))^2)/SSx)
SEb = s/sqrt(SSx)

# Regression Parameters:
# Alpha 95% CI Interval
c(model$coefficients[1] - qt(0.975,n-2)*SEa,
  model$coefficients[1] + qt(0.975,n-2)*SEa)
# Beta 95% CI Interval
c(model$coefficients[2] - qt(0.975,n-2)*SEb,
  model$coefficients[2] + qt(0.975,n-2)*SEb)

# For x = 20, confidence level for \widehat{\mu}_{0}:
x0 = 20
mu0Hat = model$coefficients[1] + model$coefficients[2]*x0
SEMu0 = s*sqrt((1/n) + (((x0-mean(x))^2)/SSx))
c(mu0Hat - qt(0.975,n-2)*SEMu0,mu0Hat + qt(0.975,n-2)*SEMu0)
#############################################################

# Confidence Intervals: R - Built-in-function:
confint(model, level=0.90)
confint(model, level=0.95)
confint(model, level=0.99)
confint(model, level=0.9999999999)
confint(model, level=0.01)

# Confidence interval for new values.
sum((x==3) | (x==7) | (x==11) | (x==17) | (x==25))
NewData1 = data.frame(x=c(3,7,11,17,25))
predict(model, NewData1, interval="confidence", level=0.95)
predict(model, NewData1, interval="confidence", level=0.99)
predict(model, NewData1, interval="confidence", level=0.01)

# Graphical presentation of confidence 
# interval similar to Figure 5.6
NewData2 = data.frame(x=0:35)
plot(x, y, pch=19, 
     xlab="Stearic Acid %", 
     ylab="Digestibility %", 
     xlim=c(0,35), 
     ylim=c(65,100))
abline(model)
NewPred2 = predict(model, NewData2, 
                   interval="confidence", level=0.95)
lines(NewData2$x, NewPred2[,1])
lines(NewData2$x, NewPred2[,2],lty=3,col="purple")
lines(NewData2$x, NewPred2[,3],lty=3,col="purple")
NewPred3 = predict(model, NewData2, 
                   interval="confidence", level=0.99)
lines(NewData2$x, NewPred3[,2],lty=4,col="green")
lines(NewData2$x, NewPred3[,3],lty=4,col="green")
legend("topright", lty=c(3,4), c("95%","99%"), 
       col = c("purple","green"))

detach(acidDigest)
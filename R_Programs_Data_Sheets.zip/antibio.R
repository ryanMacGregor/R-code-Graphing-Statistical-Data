# Dataset: Avaliable with "isdals" R-package!
data(antibio)
fix(antibio)
attach(antibio)

# Summary statistics, parallel boxplots
# type = factor(type,
#               levels = c("Control","Alfacyp",
#                          "Enroflox","Fenbenda",
#                          "Ivermect","Spiramyc"))
summary(antibio)

boxplot(org ~ type, 
        col="purple", 
        ylab ="Organic Material")

# Linear model with type and stripcharts:
model1 = lm(org ~ type-1) # -1 is to get group means.
model1
summary(model1)

# Stripcharts with group means and mean of the entire dataset.
boxplot(fitted(model1) ~ type, 
        names = c("Alp","Con","Enr","Fen","Ive","Spi"), 
        ylab = "Organic Material", ylim = range(org))
abline(mean(org), 0, lty = 2)
points(type, org, pch = 19, col = 'purple')

# Computing sample standard deviation for each type:
sd(org[type == "Alfacyp"])
sd(org[type == "Control"])
sd(org[type == "Enroflox"])
sd(org[type == "Fenbenda"])
sd(org[type == "Ivermect"])
sd(org[type == "Spiramyc"])

# ANOVA table, confidence intervals
# Manual calculation of ANOVA's entries:
#######################################
# Sum of residual squares:
G1 = sum((org[type == "Alfacyp"] - model1$coefficients[1])^2)
G2 = sum((org[type == "Control"] - model1$coefficients[2])^2)
G3 = sum((org[type == "Enroflox"] - model1$coefficients[3])^2)
G4 = sum((org[type == "Fenbenda"] - model1$coefficients[4])^2)
G5 = sum((org[type == "Ivermect"] - model1$coefficients[5])^2)
G6 = sum((org[type == "Spiramyc"] - model1$coefficients[6])^2)

sumRes2 = G1+G2+G3+G4+G5+G6
sumRes2

# Residual sample variance is:

s2 = sumRes2/(length(org) - 6) # This is also MS_e
s2

# Computation of SS_grp
count = c(sum(type == "Alfacyp"),
          sum(type == "Control"),
          sum(type == "Enroflox"),
          sum(type == "Fenbenda"),
          sum(type == "Ivermect"),
          sum(type == "Spiramyc"))
mVec = c((model1$coefficients[1]-mean(org))^2,
         (model1$coefficients[2]-mean(org))^2,
         (model1$coefficients[3]-mean(org))^2,
         (model1$coefficients[4]-mean(org))^2,
         (model1$coefficients[5]-mean(org))^2,
         (model1$coefficients[6]-mean(org))^2)
SS_grp = sum(count*mVec)
SS_grp
MS_grp = SS_grp/5
MS_grp

F_obs = MS_grp/s2
F_obs
1-pf(F_obs,df1=5,df2=28)
#######################################

# Computation by using R built-in "aov" function:
model2 = aov(org ~ type)
model2
summary(model2)
detach(antibio)

# Parasite Counts for Salmon!
# Needed for Worksheet_Group1

# Original Data:
Atran  = c(31,31,32,22,41,31,29,40,41,39,36,17,29)
Conon = c(18,26,16,20,14,28,18,27,17,32,19,17,28)

originalMeans = c(mean(Atran),mean(Conon))
originalMeans

# Generated Samples:
AtranSampling = function(n) {
  AtranSample = sample(15:45, n, replace = T)
  AsMean = mean(AtranSample)
  
  out = list()
  
  out$ASample =  AtranSample
  out$MinMax = c(min(AtranSample), max(AtranSample))
  out$AsMean = AsMean
  
  return(out)
}

CononSampling = function(n) {
  CononSample = sample(10:35, n, replace = T)
  CsMean = mean(CononSample)
  
  out = list()
  
  out$ASample = CononSample
  out$MinMax = c(min(CononSample), max(CononSample))
  out$AsMean = CsMean
  
  return(out)
}

# Generating samples for Salmon from Atran River.
AtranSampling(13)

# Generating samples for Salmon from Conon River.
CononSampling(13)
2
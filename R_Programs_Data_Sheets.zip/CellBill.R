# This program is to analyze
# the dataset "CellBill.csv"
# Asked in HW Assignment #8.

rm(list=ls())
CellBill = read.csv(file.choose(), header=T)
attach(CellBill)
n = length(BILL)

# Different plots.
par(mfrow = c(1,3))
boxplot(BILL, col="purple", ylab ="Cell Phone Bills")

hist(BILL, col='purple', freq=F, 
     xlab="Cell Phone Bills", main = "Cell Phone Bills")

qqnorm(BILL, pch = 19, col = 'purple')
qqline(BILL, col = 'red', lwd = 2)
par(mfrow = c(1,1))

# One mean t-test.
# H_{0}: mu = 49.94 vs H_{a}: mu < 49.94.
# Singnificance Level, alpha = 0.05.
muHat1 = mean(BILL)
s1 = sd(BILL)
mu = 49.94
# Computing Test Statistic
t1 = (muHat1-mu)/(s1/sqrt(n))
t1
# Threshold
qt(0.15,n-1)
# Decision
# We do not reject the null hypothesis.

# In short:
t.test(BILL, mu=49.94, alternative="less",conf.level=0.85)

#---------------------------------
# Analysis for the same data
# after removing the two largest
# observation.
sBILL = sort(BILL)
mBILL = sBILL[1:(n-2)]

par(mfrow = c(1,3))
boxplot(mBILL, col="purple", ylab ="Cell Phone Bills")

hist(mBILL, col='purple', freq=F, 
     xlab="Cell Phone Bills", main = "Cell Phone Bills")

qqnorm(mBILL, pch = 19, col = 'purple')
qqline(mBILL, col = 'red', lwd = 2)
par(mfrow = c(1,1))

# One mean z-test.
# H_{0}: mu = 49.94 vs H_{a}: mu < 49.94.
# Singnificance Level, alpha = 0.05.
m = length(mBILL)
muHat2 = mean(mBILL)
s2 = sd(mBILL)
# Computing Test Statistic
t2 = (muHat2-mu)/(s2/sqrt(m))
t2
# Threshold
qt(0.15,m-1)
# Decision
# We do reject the null hypothesis this time!

# In short:
t.test(mBILL, mu=49.94, alternative="less",conf.level=0.85)

detach(CellBill)
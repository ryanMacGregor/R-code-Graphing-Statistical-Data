# Dataset: Avaliable with "isdals" R-package!
data(chickwts)
Data = chickwts
fix(Data)
attach(Data)

# Summary statistics, parallel boxplots
feed = factor(feed, 
              levels = c("casein","horsebean",
                         "linseed","meatmeal",
                         "soybean","sunflower"))
summary(Data)
boxplot(weight ~ feed, col="purple", ylab ="Weight")

# Linear model with type and stripcharts:
model1 <- lm(weight ~ feed-1)
model1
summary(model1)

boxplot(fitted(model1) ~ feed, 
        names = c("Cas-","Hor-",
                  "Lin-","Mea-",
                  "Soy-","Sun-"), 
        ylab = "Weight", 
        ylim = range(weight))
abline(mean(weight), 0, lty = 2)
points(feed, weight, pch = 19, col = 'purple')

# Computing sample standard deviation for each type:
sd(weight[feed == "casein"])
sd(weight[feed == "horsebean"])
sd(weight[feed == "linseed"])
sd(weight[feed == "meatmeal"])
sd(weight[feed == "soybean"])
sd(weight[feed == "sunflower"])

# Computation by using R built-in "aov" function:
model2 <- aov(weight ~ feed)
model2
summary(model2)
detach(Data)


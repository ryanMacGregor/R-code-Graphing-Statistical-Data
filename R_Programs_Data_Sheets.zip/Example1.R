nSum = function(n) {
  nSumVec = rep(0,n)
  for (i in 1:n) {
    nSumVec[i] = sum(1:i)
  }
  return(nSumVec)
}
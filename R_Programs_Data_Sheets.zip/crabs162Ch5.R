# Chapter 5: 162 Crabs weights Example
# Dataset: crabs162.csv

crabs162 = read.csv(file.choose(), header = T)
names(crabs162)
fix(crabs162)
attach(crabs162)

# Use of variable names "wgt", and find summary statistics
summary(wgt)
mu = mean(wgt)
mu
sigma = sd(wgt)
sigma

boxplot(wgt, col="purple", ylab="Weight")

sampleSize = length(wgt)

# Statistical model with mean.
model = lm(wgt ~ 1)
model

summary(model)

boxplot(fitted(model), ylab="Weight", range=0, ylim=range(wgt))
points(rep(1,length(wgt)), wgt, pch=19, col="purple")

n = length(wgt)

# Number of samples to be generated.
m = 100
muHatV = rep(0,m)
for (i in 1:m) {
  set.seed(i)
  simData = rnorm(n,mu,sigma)
  muHatV[i] = mean(simData)
}
muHatV 

obsSEMuHat = sd(muHatV) 
obsSEMuHat
SE = sigma/sqrt(n)
SE

# 92% CI with normal assumption!
c(mu+SE*qnorm((1-.92)/2),mu+SE*qnorm((1+.92)/2))


# 92% CI with t-distribution.
p = 0.92
pQuant = qt(((1+p)/2), df=n-1)
lLim = mu-pQuant*SE
uLim = mu+pQuant*SE
c(lLim,uLim)

# Different CI with linear model:
# Manual Calulation:
# 95% CI
alpha5 = 0.05
c(mu-qt(1-(alpha5/2),n-1)*SE,mu+qt(1-(alpha5/2),n-1)*SE)
# 99% CI
alpha1 = 0.01
c(mu-qt(1-(alpha1/2),n-1)*SE,mu+qt(1-(alpha1/2),n-1)*SE)

# Different CI with linear model.
confint(model, level=0.90)
confint(model, level=0.92)
confint(model, level=0.99)
confint(model, level=1)

# Confidence interval from t.test()
t.test(wgt, conf.level=0.95)
t.test(wgt, conf.level=0.99)

detach(crabs162)



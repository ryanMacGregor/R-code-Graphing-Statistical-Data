# Chapter 4: 162 Crabs weights Example
# Dataset: crabs162.csv

crabs162 = read.csv(file.choose(), header = T)
names(crabs162)
fix(crabs162)
attach(crabs162)

# Summary of the variable "wgt"
summary(wgt)
mu = mean(wgt)
mu
sigma = sd(wgt)
sigma

# A relative frequency histogram vs. normal approximation
hist(wgt, col = 'purple', freq = F, breaks = 10, 
     xlab = "Weight", main = "Crab Weights in Grams")
a = seq(min(wgt), max(wgt), length = 1000)
lines(a, dnorm(a, mu, sigma), col='blue', lwd = 3)

# A proportion between 16 and 18
n = length(wgt[wgt >= 16 & wgt <= 18])
n
obsProp1 = n/length(wgt)
obsProp1
x = seq(16,18,length=50)
polygon(c(x,18,16),c(dnorm(x, mu, sigma),0,0),col = 'green',density=20)
estProb1 = pnorm(18, mu, sigma) - pnorm(16, mu, sigma)
estProb1

# A proportion between 8 and 14
m = length(wgt[wgt >= 8 & wgt <= 14])
m
obsProp2 = m/length(wgt)
obsProp2
y = seq(8,14,length=500)
polygon(c(y,14,8),c(dnorm(y, mu, sigma),0,0),col = 'green',density=20)
estProb2 = pnorm(14, mu, sigma) - pnorm(8, mu, sigma)
estProb2

# Create a QQ-plot with a straight line
qqnorm(wgt, pch = 19, col = 'purple')
qqline(wgt, col = 'red', lwd = 2)

detach(crabs162)
sFun = function(x) {
  cat("The square of ", x, " is ", x^2, " \n")
}
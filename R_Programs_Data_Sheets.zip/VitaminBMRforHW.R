# Chapter 4: Vitamin A Intake and BMR
# Dataset: vitamina.txt

vitamina = read.table(file.choose(), header = T)
fix(vitamina)
attach(vitamina)
names(vitamina)

# Scaled BMR Dataset!
bmrS = bmr/1000

# Summary of the variable "bmr" for men:
bmrM = bmrS[sex==1]
summary(bmrM)
muM = mean(bmrM)
muM
sigmaM = sd(bmrM)
sigmaM

# Normal Approximated 95% confidence interval:
c(muM+sigmaM*qnorm(0.025),muM+sigmaM*qnorm(0.975))

#par(mfrow = c(1,2))
hist(bmrM, freq = F, breaks = 20, col = 'purple', xlab = "BRM for Men", main = "")
a = seq(min(bmrM), max(bmrM), length = 1000)
lines(a, dnorm(a, muM, sigmaM), col='blue', lwd = 3)
qqnorm(bmrM, pch = 19, col = 'purple')
qqline(bmrM, col = 'red',lwd = 2)
#par(mfrow = c(1,1))

# A proportion between 8 and 10
m1 = length(bmrM[bmrM >= 8 & bmrM <= 10])
m1
obsPropm1 = m1/length(bmrM)
obsPropm1
xM = seq(8,10,length=500)
hist(bmrM, freq = F, breaks = 20, col = 'purple', xlab = "log(Vitamin A for Men)", main = "")
bM = seq(min(bmrM), max(bmrM), length = 1000)
lines(bM, dnorm(bM, muM, sigmaM), col='blue', lwd = 3)
polygon(c(xM,10,8),c(dnorm(xM, muM, sigmaM),0,0),col = 'green',density=20)
estProbm1 = pnorm(10, muM, sigmaM) - pnorm(8, muM, sigmaM)
estProbm1

# Summary of the variable "bmr" for women:
bmrF = bmrS[sex==2]
summary(bmrF)
muF = mean(bmrF)
muF
sigmaF = sd(bmrF)
sigmaF

par(mfrow = c(1,2))
hist(bmrF, freq = F, breaks = 20, col = 'purple', xlab = "BRM for Women", main = "")
a = seq(min(bmrF), max(bmrF), length = 1000)
lines(a, dnorm(a, muF, sigmaF), col='blue', lwd = 3)
qqnorm(bmrF, pch = 19, col = 'purple')
qqline(bmrF, col = 'red',lwd = 2)
par(mfrow = c(1,1))

# Summary of the variable "bmr" for both men and women:
summary(bmrS)
mu = mean(bmrS)
mu
sigma = sd(bmrS)
sigma

par(mfrow = c(1,2))
hist(bmrS, freq = F, breaks = 20, col = 'purple', xlab = "BRM for both Men and Women", main = "")
a = seq(min(bmrS), max(bmrS), length = 1000)
lines(a, dnorm(a, mu, sigma), col='blue', lwd = 3)
qqnorm(bmrS, pch = 19, col = 'purple')
qqline(bmrS, col = 'red',lwd = 2)
par(mfrow = c(1,1))

detach(vitamina)
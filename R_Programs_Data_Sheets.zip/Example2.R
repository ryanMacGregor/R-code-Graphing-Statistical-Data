check1 <- function (x){
  y = x^2
  return (cat("The square of ", x, "is ", y, "\n"))
}
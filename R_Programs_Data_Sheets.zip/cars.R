# This program is to analyze the dataset
# cars available with datasets package.

# Call the dataset "cars" from R:
data(cars)
help(cars)
fix(cars)
attach(cars)
# Export the data as .csv file.
write.table(cars, "cars.csv", sep = ",", row.names = F)

# You may creat the scatter plot in either of the 
# follosing two ways:
plot(cars, 
     xlab = "Speed (mph)", 
     ylab = "Stopping distance (ft)", 
     las = 1, 
     pch = 19, 
     col = 'purple')

# Or, you may supply the command:
plot(speed, dist, 
     xlab = "Speed (mph)", 
     ylab = "Stopping distance (ft)", 
     las = 1, 
     pch = 19, 
     col = 'purple')

# Regress the stopping distance with speed.
model = lm(dist~speed)
model

# Plot the fitted regression line in the same plot as the original data.
plot(speed, dist, 
     xlab = "Speed (mph)", 
     ylab = "Stopping distance (ft)", 
     las = 1, 
     pch = 19, 
     col = 'purple')
abline(model, col = 'red')

# Sum of residuals squares:
distHat = predict(model)
res = residuals(model)
res2 = res^2
sum(res2)

# Computing correlation coefficient:
cor(speed,dist)

# Display all data together!
cbind(speed, dist, distHat, res, res2)

# What is the sume of the square of residuals?
sum(res2)

# Standard deviation of residuals:
sd(res)

#----------------------------------------
# Residual analysis of the linear model:
# Normality check of the residuals.
par(mfrow=c(2,2))
# First:
plot(speed,dist,col='purple',pch=19)
abline(model,col='red',lwd=2)

# Second:
plot(distHat,res,col='purple',pch=19,ylab="Residuals")
abline(h=0,col='red',lwd=2)

# Third:
qqnorm(res,col='purple',pch=19)
qqline(res,col='red',lwd=2)

# Fourth:
hist(res,freq=F,
     col='purple',
     ylim=c(0,0.035),
     xlab="Residuals",
     main="Hist. of Residuals",
     xlim=c(-60,60))
lines(density(res,from=-60,to=60),col='red',lwd=2)
a = seq(-60, 60, length = 1000)
lines(a,dnorm(a,mean(res),sd(res)),col='blue',lwd=2)

par(mfrow=c(1,1))
dev.off()
#----------------------------------------

# Model prediction.
sum(speed==21)

model$coefficients[1]+model$coefficients[2]*21

# Residual of the coordinate (13,46)
pred46 = model$coefficients[1]+model$coefficients[2]*13
res46 = 46-pred46
res46

# Calulation of R^2:
summary(model)

detach(cars)

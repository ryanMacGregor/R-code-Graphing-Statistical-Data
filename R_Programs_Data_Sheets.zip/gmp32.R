# This is Home Assignment for Data Types.
# MATH 3070 - Statistical Methods I
# Tenn Tech University
#
# This program is to analyze the different 
# variables of the 
# "Gasoline Milage Performance for 32 Automobiles"
# dataset, gmp32.csv
# Read the data on RStudio

gmp32 = read.csv(file.choose(), header = TRUE)
attach(gmp32)
fix(gmp32)
names(gmp32)

# Mosaic plot of No. of transmission
# vs Type of transmission
mosaicplot(table(x7, x11),
           col = c("purple", "blue"), 
           main="Mosaic Plot",
           xlab="No. of Transmission",
           ylab="Type of Transmission")

# Scatter plot of mpg vs horsepower (Chapter 2).
plot(y, x2, 
     xlab = "MPG", 
     ylab = "Horsepower", 
     main = "MPG vs Horsepower Relation")

# Scatter plot of horsepower vs weight (Chapter 2).
plot(x2, x10, 
     xlab = "MPG", 
     ylab = "Horsepower", 
     main = "Horsepower vs Weight Relation")

# The following lines produce three 
# frequency histograms for mpg just in one picture.
par(mfrow = c(1,3))
hist(y, freq = TRUE, col = 'purple', 
     xlab = "MPG of Cars", 
     ylab = "Frequency", 
     main = "Histogram")
hist(y[x11 == 1], freq = TRUE, col = 'purple', 
     xlab = "MPG of Cars, A", 
     ylab = "Frequency", 
     main = "Histogram")
hist(y[x11 == 0], freq = TRUE, col = 'purple', 
     xlab = "MPG of Cars, M", 
     ylab = "Frequency", 
     main = "Histogram")
par(mfrow = c(1,1))

par(mfrow = c(1,3))
hist(y, freq = TRUE, breaks = 10, col = 'purple', 
     xlab = "MPG of Cars", 
     ylab = "Frequency", 
     main = "Histogram")
hist(y[x11 == 1], freq = TRUE, breaks = 10, 
     col = 'purple', 
     xlab = "MPG of Cars, A", 
     ylab = "Frequency", 
     main = "Histogram")
hist(y[x11 == 0], freq = TRUE, breaks = 10, 
     col = 'purple', 
     xlab = "MPG of Cars, M", 
     ylab = "Frequency", 
     main = "Histogram")
par(mfrow = c(1,1))

# The following line produce modified boxplots of "mpg"
boxplot(y, y[x11 == 1], y[x11 == 0], col = 'purple',
        names = c("MPG", "MPG-A", "MPG-M"), pch = 19, 
        horizontal = F, ylab = "MPG")

# The following lines produce three relative
# frequency histograms for weight just in one picture.
par(mfrow = c(1,3))
hist(x10, freq = FALSE, col = 'purple', 
     xlab = "Weight of Cars, All", 
     ylab = "Relative Frequency", 
     main = "Histogram")
hist(x10[x11 == 1], freq = FALSE, col = 'purple', 
     xlab = "Weight of Cars, A", 
     ylab = "Relative Frequency", 
     main = "Histogram")
hist(x10[x11 == 0], freq = FALSE, col = 'purple', 
     xlab = "Weight of Cars, M", 
     ylab = "Relative Frequency", 
     main = "Histogram")
par(mfrow = c(1,1))

# The following line produce modified boxplots of "weight"
boxplot(x10, x10[x11 == 1],x10[x11 == 0], col = 'purple',
        names = c("Weight", "Weight-A", "Weight-M"), 
        ylab = "Weight", horizontal = F)
# How many number of transmission speeds are 
# there for those vehicles whose weights were 
# identified as outliers?
x7[x10>5200]

# Summary statistics.
SummY = summary(y)
SummY
IQR(y)
sd(y)
c(SummY[2]-1.5*IQR(y),SummY[5]+1.5*IQR(y))

SummW = summary(x10)
SummW
IQR(x10)
sd(x10)
c(SummW[2]-1.5*IQR(x10),SummW[5]+1.5*IQR(x10))

detach(gmp32)

rm(list=ls())
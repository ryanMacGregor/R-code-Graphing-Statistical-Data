# Movie fans use the annual Leonard Martin
# Movie Guide for facts, cast members, and reviews of over
# 21,000 films. The movies are rated from 4 stars (4*), indicating
# a very good movie, to 1 star (1*), which Leonard Martin refers
# to as a BOMB. The dataset "FlimsRating.csv" gives the running times, in
# minutes, of a random sample of films listed in one year's guide. 
# Construct a one-way-ANOVA table for the dataset!

# Reading dataset:
Data = read.csv(file.choose(), header = T)
fix(Data)
attach(Data)
names(Data)

summary(Data)
boxplot(TIME ~ RATING, col="purple", ylab ="TIME")

# Linear model:
model1 <- lm(TIME ~ RATING-1)
model1
summary(model1)

# Stripcharts:
boxplot(fitted(model1) ~ RATING, ylab = "TIME", ylim = range(TIME))
abline(mean(TIME), 0, lty = 2)
points(RATING, TIME, pch = 19, col = 'purple')

# Computing sample standard deviation for each group:
sd(TIME[RATING == "1* or 1.5*"])
sd(TIME[RATING == "2* or 2.5*"])
sd(TIME[RATING == "3* or 3.5*"])
sd(TIME[RATING == "4*"])

model2 <- aov(TIME~RATING)
model2
summary(model2)

detach(Data)
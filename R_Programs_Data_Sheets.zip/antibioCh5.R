# Dataset: 
# Avaliable with "isdals" R-package!
# Chapter 5.

data(antibio)
fix(antibio)
attach(antibio)

# Linear model without intercept:
model = lm(org ~ type-1)
model
summary(model)

confint(model, level=0.90)
round(confint(model, level=0.95),2)
confint(model, level=0.99)

# Difference between group means
# assuming "Control" group as reference.
# See second bullet on p. #135, 
# from ISDALS 2nd Edition.
myRefC = relevel(type, ref = "Control")
modelC = lm(org ~ myRefC)
modelC
summary(modelC)

confint(modelC, level=0.90)
round(confint(modelC, level=0.95),2)
confint(modelC, level=0.99)


# Difference between group means
# assuming "Enroflox" group as reference.
# See second bullet on p. #135, 
# from ISDALS 2nd Edition.
myRefE = relevel(type, ref = "Enroflox")
modelE = lm(org ~ myRefE)
modelE
summary(modelE)

confint(modelE, level=0.90)
confint(modelE, level=0.95)
confint(modelE, level=0.99)

detach(antibio)


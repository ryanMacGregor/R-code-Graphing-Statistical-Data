LLNFairCoinHead = function(n){
  hVec = rep(0,n)
  for (i in 1:n) {
    hVec[i] = sample(0:1,1,replace = F)
  }
  totalHeads = sum(hVec == 1)
  return(totalHeads/n)
}

LLNFairDieF5 = function(n){
  Vec5 = rep(0,n)
  for (i in 1:n) {
    Vec5[i] = sample(1:6,1,replace = F)
  }
  total5s = sum(Vec5 == 5)
  return(c(total5s,total5s/n))
}
inData = c(1.0, 4.6, 5.4, 3.7, 5.2,
           1.7, 6.1, 1.9, 7.6, 9.1,
           6.9, 5.5, 9.0, 3.9, 2.5,
           2.4, 4.7, 4.1, 3.7, 6.2)

n = length(inData)

mu0 = 4.55

muHat = mean(inData)
muHat 

s = sd(inData)
s

tVal = ((muHat-mu0)/(s/sqrt(n)))
tVal 

tQt = qt(0.05,n-1)
tQt

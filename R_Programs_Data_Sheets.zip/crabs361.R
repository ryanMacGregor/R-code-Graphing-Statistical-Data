# This program is to analyze the dataset
# crabs available with isdals package.

# Call the dataset "crabs" from R:
# install.packages('isdals')
data(crabs)
help(crabs)
fix(crabs)
attach(crabs)
# Export the data as .csv file.
write.table(crabs, "crabs.csv", sep = ",", row.names = F)

# Regression Model:
model = lm(wgt~lgth)
model

# Regression Model - length as a function of weight:
model2 = lm(lgth~wgt)
model2

# You may creat the scatter plot in of lenth
# vs weight as well as fitted model.
plot(lgth, wgt, xlab = "Length (cm)", ylab = "Weight (grams)", 
     las = 1, pch = 19, col = 'purple')
abline(model, col = 'red')

# Weight of a particular crab with length 6.5 cm.
sum(lgth == 6.5)
wgt[lgth == 6.5]

# Weight of a particular crab with length 6.4 cm.
sum(lgth == 6.4) # There are non!
# Predicted weight!
model$coefficients[1]+model$coefficients[2]*6.4

# Residual calculation for  (9,29.90).
yHat1 = model$coefficients[1]+model$coefficients[2]*9
residual1 = 29.90 - yHat1
residual1

# Fitted Values with Residuals
wgtHat = predict(model)
res = residuals(model)
res2 = res^2
sum(res)
sum(res2)

cbind(lgth, wgt, wgtHat, res, res2)

#----------------------------------------
# Residual analysis of the linear model:
par(mfrow=c(2,2))
# First:
plot(lgth,wgt,col='purple',pch=19)
abline(model,col='red',lwd=2)

# Second:
plot(wgtHat,res,col='purple',pch=19,ylab="Residuals")
abline(h=0,col='red',lwd=2)

# Third:
qqnorm(res,col='purple',pch=19)
qqline(res,col='red',lwd=2)

# Fourth:
hist(res,freq=F,
     col='purple',
     ylim=c(0,0.30),
     xlab="Residuals",
     main="Hist. of Residuals",
     xlim=c(-10,10))
lines(density(res,from=-10,to=10),col='red',lwd=2)
a = seq(-10, 10, length = 1000)
lines(a,dnorm(a,mean(res),sd(res)),col='blue',lwd=2)

par(mfrow=c(1,1))
dev.off()
#----------------------------------------

# Correlation Coefficient:
rho = cor(lgth,wgt)
rho
R2 = rho^2
R2

summary(model)

# Summary of the variable "wgt"
summary(wgt)
sd(wgt)
IQR(wgt)

detach(crabs)
rm(list=ls())

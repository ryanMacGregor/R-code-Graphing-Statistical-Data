# This program is to analyze the tenderness of 
# pork meat data set, cooling.txt
# Read the data on RStudio

cooling = read.table(file.choose(), header = TRUE)
attach(cooling)
# fix(cooling)
names(cooling)

# Scatter plot of Tunnel vs Rapid (Chapter 2).
plot(tunnel, rapid, 
     xlab = "Tunnel", 
     ylab = "Rapid", 
     main = "Tenderness of Pork Meat")

# The following lines produce modified 
# boxplots of "tunnel" and "rapid" methods.
boxplot(tunnel, rapid, 
        names = c("Tunnel", "Rapid"),
        col = 'purple', pch = 19,
        ylab = "Tenderness Score")

# The following lines produce four frequency 
# histograms just in one picture.
par(mfrow=c(2,2))
hist(rapid[ph == "low"], 
     freq = TRUE, breaks = 10, 
     col = 'purple', 
     xlab = "Tenderness (low pH)", 
     ylab = "Frequency", 
     main = "Histogram")
hist(rapid[ph == "high"], 
     freq = TRUE, breaks = 10, 
     col = 'purple', 
     xlab = "Tenderness (high pH)", 
     ylab = "Frequency", 
     main = "Histogram")
hist(rapid[ph == "low"], 
     freq = FALSE, breaks = 10, 
     col = 'purple', 
     xlab = "Tenderness (low pH)", 
     ylab = "Frequency", 
     main = "Histogram")
hist(rapid[ph == "high"], 
     freq = FALSE, breaks = 10, 
     col = 'purple', 
     xlab = "Tenderness (high pH)", 
     ylab = "Frequency", 
     main = "Histogram")

# Numerical summaries:
mean(tunnel)
median(tunnel)
IQR(tunnel)
sd(tunnel) # Saple standard deviation

mean(rapid)
median(rapid)
IQR(rapid)
sd(rapid) # Saple standard deviation

summary(tunnel)
summary(rapid)

detach(cooling)
par(mfrow=c(1,1))


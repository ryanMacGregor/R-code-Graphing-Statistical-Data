# Parasite Counts for Salmon!

Atran  = c(31,31,32,22,41,31,29,40,41,39,36,17,29)
Conon = c(18,26,16,20,14,28,18,27,17,32,19,17,28)

# The following line produce modified boxplots:
boxplot(Atran, Conon, 
        col = 'purple', 
        names = c("Atran", "Conon"), 
        horizontal = F, 
        ylab = "Parasite counts")

# Combining both datasets into one:
# You may not need to run this part of code.
vStock = c(rep("Atran",length(Atran)),rep("Conon",length(Conon)))
vParasites = c(Atran, Conon)
Data = data.frame("Stock" = vStock, "Parasites" = vParasites) 
fix(Data)
attach(Data)
fStock = factor(vStock, levels = c("Atran","Conon"))
boxplot(Parasites ~ Stock, col = "purple", ylab = "Parasite counts")
model = lm(Parasites ~ Stock - 1)
summary(model)
boxplot(fitted(model) ~ Stock, ylab = "Parasite counts", ylim = range(Parasites))
abline(mean(Parasites), 0, lty = 2)
points(fStock, Parasites, pch = 19, col = 'purple')

model = aov(Parasites ~ Stock)
summary(model)

detach(Data)

# Statistical summary:
summary(Atran)
sd(Atran)
summary(Conon)
sd(Conon)


# Difference between means:
mean(Atran) - mean(Conon)
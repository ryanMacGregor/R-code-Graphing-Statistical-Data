# SpouseData, Contingency Table.

inData = read.csv(file.choose(),header=T)
# Supply the dataset "gender_spouse.csv"
fix(inData)

# Contingency Table.
FeqTable = table(inData)
FeqTable

# Relative Frequency Table.
rFeqTable = round(prop.table(FeqTable,margin=2),4)
rFeqTable

# Frequency bar chart.
par(mfrow=c(1,2))
barplot(table(inData$gender), 
        beside = TRUE, 
        names.arg = c("Female", "Male"), 
        col = c("pink", "blue"), 
        main = "Frequency Bar Chart",
        legend.text = TRUE, 
        args.legend = list(x="topright"))
# Relative Frequency bar chart.
barplot(table(inData$gender)/sum(table(inData$gender)), beside = TRUE, 
        names.arg = c("Female", "Male"), 
        col = c("pink", "blue"), 
        main = "Relative Frequency Bar Chart", 
        legend.text = TRUE, 
        args.legend = list(x="topright"))
par(mfrow=c(1,1))
dev.off()

# Frequency segmented bar chart.
par(mfrow=c(1,2))
barplot(table(inData$spouse, inData$gender), 
        col = c("purple", "blue"), 
        main = "Frequency Segmented Bar Chart", 
        legend.text = TRUE, 
        args.legend = list(x="topright"))
# Relative Frequency segmented bar chart.
barplot(prop.table(table(inData$spouse, inData$gender),2), 
        col = c("purple", "blue"),
        main = "Relative Frequency Segmented Bar Chart", 
        legend = FALSE)
par(mfrow=c(1,1))
dev.off()

# Mosaic plots.
mosaicplot(table(inData$gender, inData$spouse),
           col = c("purple", "blue"), 
           main="Mosaic Plot")
dev.off()










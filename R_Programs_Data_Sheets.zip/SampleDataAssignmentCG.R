# Sample data, Assignment for
# Comparision of Groups
# Number 1:

# Reading dataset:
# Data to be read: sampleData.csv:
Data = read.csv(file.choose(), header = T)
fix(Data)
attach(Data)
names(Data)

summary(Data)
IQR(OBSERVATION)

boxplot(OBSERVATION ~ SAMPLE, 
        col="purple", ylab ="")

# Linear model:
model1 <- lm(OBSERVATION ~ SAMPLE-1)
model1
summary(model1)

# Stripcharts:
boxplot(fitted(model1) ~ SAMPLE, 
        ylab = "", 
        ylim = range(OBSERVATION))
abline(mean(OBSERVATION), 0, lty = 2)
points(factor(SAMPLE), OBSERVATION, 
       pch = 19, 
       col = 'purple')

# Computing sample standard deviation for each group:
mean(OBSERVATION[SAMPLE == "A"])
sd(OBSERVATION[SAMPLE == "A"])
mean(OBSERVATION[SAMPLE == "B"])
sd(OBSERVATION[SAMPLE == "B"])
mean(OBSERVATION[SAMPLE == "C"])
sd(OBSERVATION[SAMPLE == "C"])
mean(OBSERVATION[SAMPLE == "D"])
sd(OBSERVATION[SAMPLE == "D"])
mean(OBSERVATION[SAMPLE == "E"])
sd(OBSERVATION[SAMPLE == "E"])

model2 <- aov(OBSERVATION~SAMPLE)
model2
summary(model2)

detach(Data)
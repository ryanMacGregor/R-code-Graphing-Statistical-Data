# This program is to solve Exercise 2.3 on p. 47
# from the textbook ISDALS.

# install.package('isdals')
# library(isdals)

# Call the dataset "trees" from R:
# Part 1:
data(trees)
help(trees)
fix(trees)
attach(trees)
# Export the data as .csv file.
write.table(trees, "trees.csv", 
            sep = ",", row.names = F)

# Parts 2 and 3:
par(mfrow = c(1,3))
plot(Height, Volume, pch = 19, col = 'purple')
plot(Girth, Volume, pch = 19, col = 'purple')
plot(Girth, Height, pch = 19, col = 'purple')
par(mfrow = c(1,1))

# Part 4:  
# We want that Volume as a linear function
# of Girth. That is,
# Voluem = a + b Girth
# y = a + b x
M = lm(Volume~Girth)
# The linear model is:
# Volume = -36.943 + 5.066 Girth 

mvg = lm(Volume~Girth)
mvg

# Part 5:
plot(Girth, Volume, pch = 19, 
     xlab = "Girth", 
     ylab = "Volume", 
     col = 'purple')
abline(mvg, col = 'red')

# Part 6: 
cor(Volume, Height)
cor(Volume, Girth)
cor(Girth, Height)

# Part 7: 
cor(Height, Volume)

# Part 8:
max(Volume)
VolChange = replace(Volume, Volume == max(Volume), 35)
VolData = cbind(Volume, VolChange)
fix(VolData)
cor

# Part 9:
mvg = lm(Volume~Girth)
mvCg = lm(VolChange~Girth)
mvg
mvCg

# Part 10:
par(mfrow = c(1,2))
plot(Girth, Volume, pch = 19, 
     col = 'purple', 
     ylim = c(8,80))
abline(mvg, col = 'purple')
abline(mvCg, col = 'green')
plot(Girth, VolChange, pch = 19, 
     col = 'purple', 
     ylim = c(8,80))
abline(mvg, col = 'purple')
abline(mvCg, col = 'green')
par(mfrow = c(1,1))

detach(trees)

nSum = function(n) {
  nSeq = seq(1,n)
  sVec = rep(0,n)
  
  for (i in 1:n) {
    sVec[i] = sum(nSeq[1:i])
  }
  
  sMatrix = cbind(nSeq,sVec)
  return(t(sMatrix))
}
# Parasite Counts for Salmon!
# Needed for Worksheet_Group2

Atran  = c(31,31,32,22,41,31,29,40,41,39,36,17,29)
Conon = c(18,26,16,20,14,28,18,27,17,32,19,17,28)

n1 = length(Atran)
n2 = length(Conon)

acData = c(Atran,Conon)

aMu = mean(Atran) # y1 bar
cMu = mean(Conon) # y2 bar
Mu = mean(acData) # y bar

Mu12Vec = c(rep(aMu,13),rep(cMu,13))

aR = Atran - aMu
aR2 = aR^2

cR = Conon - cMu
cR2 = cR^2

acR = c(aR,cR)
acR2 = c(aR2,cR2)

T1E = cbind(acData, Mu12Vec, acR, acR2)

TotalRow1 = c(sum(acData), 
              mean(acData), 
              sum(acR), 
              sum(acR2))

# SSR Computation! 
T2E = cbind(c(aMu,cMu), rep(Mu,2), 
                  c(n1*(aMu-Mu),n2*(cMu-Mu)),
                    c(n1*(aMu-Mu)^2,n2*(cMu-Mu)^2))
T2E

TotalRow2 = c(sum(T2E[,1]),Mu,sum(T2E[,3]),sum(T2E[,4]))
TotalRow2

# Combining both datasets into one:
# For ANOVA Table!

vStock = c(rep("Atran",length(Atran)),rep("Conon",length(Conon)))
vParasites = c(Atran, Conon)
Data = data.frame("Stock" = vStock, "Parasites" = vParasites) 
fix(Data)
attach(Data)
fStock = factor(vStock, levels = c("Atran","Conon"))

model = aov(Parasites ~ Stock)
summary(model)

detach(Data)

                                             


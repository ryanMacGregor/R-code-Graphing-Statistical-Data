# Monthly Rent Data, 
# Assignment Comparision of Groups
# Number 2:

# Reading dataset:
# Data to be read: MonthlyRebt.csv:
Data = read.csv(file.choose(), header = T)
fix(Data)
attach(Data)
names(Data)

summary(Data)
boxplot(RENT ~ REGION, col="purple", ylab ="RENT")

# Linear model:
model1 <- lm(RENT ~ REGION-1)
model1
summary(model1)

# Stripcharts:
boxplot(fitted(model1) ~ REGION, ylab = "RENT", ylim = range(RENT))
abline(mean(RENT), 0, lty = 2)
points(REGION, RENT, pch = 19, col = 'purple')

# Computing sample standard deviation for each group:
mean(RENT[REGION == "Northeast"])
sd(RENT[REGION == "Northeast"])
mean(RENT[REGION == "Midwest"])
sd(RENT[REGION == "Midwest"])
mean(RENT[REGION == "South"])
sd(RENT[REGION == "South"])
mean(RENT[REGION == "West"])
sd(RENT[REGION == "West"])

model2 = aov(RENT~REGION)
model2
summary(model2)

detach(Data)
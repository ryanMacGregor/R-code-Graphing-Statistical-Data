# This program is to analyze
# the dataset Study Time and Score.

studyHours = c(10,15,12,20,8,16,14,22)
score = c(92,81,84,74,85,80,84,80)

model = lm(score~studyHours)
model

plot(studyHours,score, pch=19, xlab="Study Hours", ylab="Score Obtained", col='purple')
abline(model, col='purple')

summary(model)

n = length(studyHours)

qt(0.01/2,n-2)

confint(model, conf.level = 0.95)
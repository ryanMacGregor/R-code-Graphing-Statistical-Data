# Parasite Counts for Salmon!
# For Chapter 6: Hypothesis Test

Atran = c(31,31,32,22,41,31,29,40,41,39,36,17,29)
Conon = c(18,26,16,20,14,28,18,27,17,32,19,17,28)

# Statistical summary:
summary(Atran)
sd(Atran)
summary(Conon)
sd(Conon)

# t-Test with equal variance assumption:
# Test the null hypothesis: Atran = Conon
# Assuming that Atran is 1st factor (group), 
# and Conon as 2nd factor.
# That is mu_{Atran} - mu_{Conon}.

t.test(Atran,Conon,alternative="two.sided",mu=0,var.equal=T)

# Test the null hypothesis: Atran > Conon

t.test(Atran,Conon,alternative="greater", mu=0,var.equal=T)

# t-Test without equal variance assumption:
# Test the null hypothesis: Atran = Conon
# Assuming that Atran is 1st factor (group), and Conon as 2nd factor.

t.test(Atran,Conon,alternative="two.sided",mu=0,var.equal=F)

# Test the null hypothesis: Atran > Conon

t.test(Atran,Conon,alternative="less",mu=0,var.equal=F)

# Run the following line in order to clear all the variables
# introduced in this analysis.

rm(list=ls())



# Worksheet for Hypothesis Test
# Tax Efficiency: Regression Model.

Securities = c(3.1,3.2,3.7,4.3,4.0,5.5,6.7,7.4,7.4,10.6)
Efficiency = c(98.1,94.7,92.0,89.8,87.5,85.0,82.0,77.8,72.1,53.5)

n = length(Securities)

TaxEfficiency = cbind(Securities,Efficiency)
TaxEfficiency

# Linear Model: 
model = lm(Efficiency~Securities)
model

sData = summary(model)
sData 

CD = sData$coefficients

tVal = (model$coefficients[2]-0)/CD[2,2]
tVal

tQt = qt(.975,sData$df[2])
tQt

confint(model, conf.level = 0.95)

res = residuals(model)

#----------------------------------------
# Residual analysis of the linear model:
par(mfrow=c(2,2))

# First:
plot(Securities,Efficiency,col='purple',pch=19)
abline(model,col='red',lwd=2)

# Second:
plot(res,col='purple',pch=19,ylab="Residuals")
abline(h=0,col='red',lwd=2)

# Third:
qqnorm(res,col='purple',pch=19)
qqline(res,col='red',lwd=2)

# Fourth:
hist(res,freq=F,col='purple',ylim=c(0,0.2),xlab="Residuals",main="Hist. of Residuals")
lines(density(res),col='red',lwd=2)
a = seq(min(res)-2, max(res)+2, length = 1000)
lines(a,dnorm(a,mean(res),sd(res)),col='blue',lwd=2)

par(mfrow=c(1,1))
#----------------------------------------




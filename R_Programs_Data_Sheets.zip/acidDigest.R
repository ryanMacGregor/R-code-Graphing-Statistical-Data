# This program dose the regression analysis
# for the dataset "Stearic Acid and Digestibility of Fat"

# Read the dataset in RStudio and attach the variables.
acidDigest = read.csv(file.choose(), header = T)
fix(acidDigest)
attach(acidDigest)

# Compute the regressiong model for the dataset.
model = lm(y ~ x)
model

# Construct a scatter plot including the fitted line.
plot(x,y, pch = 19, 
     xlab = "Steraic Acid %", 
     ylab = "Digestibility %", 
     col = 'purple')
abline(model, col = 'red')

# Different statistical computation.
yHat = predict(model) 
res = residuals(model)
res2 = res^2
cbind(x, y, yHat, res, res2)
sum(res2)
cor(x,y)

detach(acidDigest)
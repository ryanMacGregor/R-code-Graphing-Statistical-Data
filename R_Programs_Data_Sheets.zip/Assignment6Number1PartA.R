# HW 6 Number 1 Part (a)
# P(T < 1.45, df = 4)

TScore = 1.45

df = 4

t = seq(-5,5,length = 500)

denFun = dt(t,df)


plot(t, denFun, xlim=c(-5,5), type="l",col='red',lty=1,lwd=2,
      xlab="T",ylab='Density Function',ylim = c(-0.02,0.40))
abline(h=0,lty=2,col='blue')
prob = pt(TScore,df)
text(-2.5,0.3, paste0("Area = ",round(prob, 2)))
text(1.70,-0.015, paste0("T = ",round(TScore, 2)))
arg.x = c(-5,t[t <= TScore],TScore)
arg.y = c(0,denFun[(t <= TScore)],0)
polygon(arg.x,arg.y,col="purple")

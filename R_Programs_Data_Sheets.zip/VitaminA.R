# Chapter 4: Vitamin A Intake and BMR
# Dataset: vitamina.txt

# vitamina = read.table(file.choose(), header = T)
data(vitamina)
fix(vitamina)
attach(vitamina)
names(vitamina)

# Summary of the variable "Avit" for men:
AvitM = Avit[sex==1]
lAvitM = log(AvitM)
summary(AvitM)
mu1 = mean(AvitM)
mu1
sigma1 = sd(AvitM)
sigma1

summary(lAvitM)
mu2 = mean(lAvitM)
mu2
sigma2 = sd(lAvitM)
sigma2

# Creating histograms and QQ-plots:
par(mfrow = c(2,2))
hist(AvitM, freq = F, breaks = 20, 
     col = 'purple', xlab = "Vitamin A for Men", 
     main = "")
a = seq(min(AvitM), max(AvitM), length = 1000)
lines(a, dnorm(a, mu1, sigma1), col='blue', lwd = 3)

hist(lAvitM, freq = F, breaks = 20, 
     col = 'purple', xlab = "log(Vitamin A for Men)", 
     main = "")
b = seq(min(lAvitM), max(lAvitM), length = 1000)
lines(b, dnorm(b, mu2, sigma2), col='blue', lwd = 3)

qqnorm(AvitM, pch = 19, col = 'purple')
qqline(AvitM, col = 'red',lwd = 2)

# QQ-plots fro transformed data.
qqnorm(lAvitM, pch = 19, col = 'purple')
qqline(lAvitM, col = 'red',lwd = 2)
par(mfrow = c(1,1))

# A proportion between 2000 and 4000
n = length(lAvitM[lAvitM >= log(2000) & 
                    lAvitM <= log(4000)])
n
obsProp1 = n/length(lAvitM)
obsProp1
x = seq(log(2000),log(4000),length=50)
hist(lAvitM, freq = F, breaks = 20, col = 'purple', xlab = "log(Vitamin A for Men)", main = "")
b = seq(min(lAvitM), max(lAvitM), length = 1000)
lines(b, dnorm(b, mu2, sigma2), col='blue', lwd = 3)
polygon(c(x,log(4000),log(2000)),c(dnorm(x, mu2, sigma2),0,0),col = 'green',density=20)
estProb1 = pnorm(log(4000), mu2, sigma2) - pnorm(log(2000), mu2, sigma2)
estProb1

detach(vitamina)
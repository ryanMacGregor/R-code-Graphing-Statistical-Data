# This program computes the confidence intervals of linear
# model for the dataset "Rocket Propellant Data"
# Dataset: Rocket_Prop.csv

Rocket_Prop = read.csv(file.choose(), header=T)
attach(Rocket_Prop)
summary(Rocket_Prop)
fix(Rocket_Prop)

plot(x,y,xlab="Age of Propellant, x",ylab="Shear Strength, y",pch=19,col='purple')

# Linear Model -- lm()
model = lm(y ~ x)
model
summary(model)

# How well does the linear model fit?
cor(x, y)

#############################################################
# Confidence Intervals: Manual Calculations:
n = length(x)
yHat = predict(model) 
SSe = sum((y-yHat)^2)
SSx = sum((x-mean(x))^2)
s = sqrt(SSe/(n-2))
SEa = s*sqrt((1/n)+((mean(x))^2)/SSx)
SEb = s/sqrt(SSx)

# Regression Parameters:
# Alpha 95% CI Interval
c(model$coefficients[1] - qt(0.975,n-2)*SEa,model$coefficients[1] + qt(0.975,n-2)*SEa)
# Beta 95% CI Interval
c(model$coefficients[2] - qt(0.975,n-2)*SEb,model$coefficients[2] + qt(0.975,n-2)*SEb)

# For x = 20, confidence level for \widehat{\mu}_{0}:
x0 = 20
mu0Hat = model$coefficients[1] + model$coefficients[2]*x0
SEMu0 = s*sqrt((1/n) + (((x0-mean(x))^2)/SSx))
c(mu0Hat - qt(0.975,n-2)*SEMu0,mu0Hat + qt(0.975,n-2)*SEMu0)
#############################################################

# Confidence Intervals: R - Built-in-function:
round(confint(model, level=0.95),2)

# Confidence interval for new values.
sum((x==10) | (x==12) | (x==15) | (x==16) | (x==20))
NewData1 = data.frame(x=c(10,12,15,16,20))
round(predict(model, NewData1, interval="confidence", level=0.95),2)

# Graphical presentation of confidence interval similar to Figure 5.6
NewData2 = data.frame(x=min(x):max(x))
plot(x, y, pch=19, xlab="Age of Propellant, x", ylab="Shear Strength, y", xlim=c(min(x),max(x)))
NewPred2 = predict(model, NewData2, interval="confidence", level=0.95)
lines(NewData2$x, NewPred2[,1])
lines(NewData2$x, NewPred2[,2],lty=3,col="red")
lines(NewData2$x, NewPred2[,3],lty=3,col="red")
legend("topright", lty=c(3,4), c("95%"), col = c("red"))

detach(Rocket_Prop)
# Parasite Counts for Salmon!
# For Chapter 5.

Atran  = c(31,31,32,22,41,31,29,40,41,39,36,17,29)
Conon = c(18,26,16,20,14,28,18,27,17,32,19,17,28)

# Statistical summary:
summary(Atran)
sd(Atran)
summary(Conon)
sd(Conon)


# Difference between means:
mean(Atran) - mean(Conon)

# The following line produce modified boxplots:
boxplot(Atran, Conon, col = 'purple', names = c("Atran", "Conon"), horizontal = F, ylab = "Parasite counts")

# Combining both datasets into one:
# You may not need to run this part of code.
vStock = c(rep("Atran",length(Atran)),rep("Conon",length(Conon)))
vParasites = c(Atran, Conon)
Data = data.frame("Stock" = vStock, "Parasites" = vParasites) 
fix(Data)
attach(Data)

model = lm(Parasites ~ Stock-1)
summary(model)

confint(model, level=0.90)
confint(model, level=0.95)
confint(model, level=0.99)

# Difference between group means
# assuming "Conon" group as reference.
# See second bullet on p. #135, 
# from ISDALS 2nd Edition.
myRefC = relevel(Stock, ref = "Conon")
modelC = lm(Parasites ~ myRefC)
modelC
summary(modelC)

confint(modelC, level=0.90)
confint(modelC, level=0.95)
confint(modelC, level=0.99)

# Difference between group means
# assuming "Atran" group as reference.
# See second bullet on p. #135, 
# from ISDALS 2nd Edition.
myRefA = relevel(Stock, ref = "Atran")
modelA = lm(Parasites ~ myRefA)
modelA
summary(modelA)

confint(modelA, level=0.90)
confint(modelA, level=0.95)
confint(modelA, level=0.99)

detach(Data)

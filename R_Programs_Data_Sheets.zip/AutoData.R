# This program is to analyze the different 
# variables of the data, Auto.data
# Read the data on RStudio

install.packages("ISLR")
library(ISLR)

data(Auto) 
attach(Auto)
help(Auto)
fix(Auto)
names(Auto)

# Frequency bar chart to identify the origin 
# of the automobiles.
barplot(table(origin), beside=TRUE,
        col = c("purple", "blue","green"),
        xlab = "Origin",
        ylab = "Frequency",
        main = "Bar plot of origin of the automobiles.",
        legend.text = TRUE, 
        args.legend = list(x="topright"))

# Frequency bar chart.
barplot(table(origin,year), beside=TRUE,
        col = c("purple", "blue","green"),
        main = "Bar plot of origin of the automobiles for diff. years.",
        legend.text = TRUE, 
        args.legend = list(x="topright"))

# Frequency segmented bar chart.
barplot(table(origin,year), beside=FALSE,
        col = c("purple", "blue","green"),
        main = "Frequency segmented bar chart.",
        legend.text = FALSE, 
        args.legend = list(x="topleft"))

# Relative Frequency segmented bar chart.
barplot(prop.table(table(origin,year),2), 
        beside=FALSE,
        col = c("purple", "blue","green"),
        main = "Relative Frequency Segmented Bar Chart.",
        legend.text = FALSE, 
        args.legend = list(x="topright"))

# Mosaic plot of Year vs Origin.
mosaicplot(table(year, origin),
           col=c("purple", "blue", "green"), 
           main="Mosaic Plot of Year vs Origin",
           xlab="Year",
           ylab="Country of Origin")

# Mosaic plot of Cylinders vs Origin.
mosaicplot(table(cylinders, origin),
           col = c("purple", "blue", "green"), 
           main="Mosaic Plot of Cylinders vs Origin",
           xlab="# of Cylinders",
           ylab="Country of Origin")

# Check how many automobiles are there
# from US having 3 cylinders.
origin[cylinders==3] # None from US and Europe.

# Check how many automobiles are there
# from US having 5 cylinders.
origin[cylinders==5] # All from Europe.

# Check how many automobiles are there
# from US having 8 cylinders.
origin[cylinders==8] # All from US.

# Scatter plot of mpg vs horsepower (Chapter 2).
plot(mpg, horsepower, 
     xlab = "MPG", 
     ylab = "Horsepower", 
     main = "MPG vs Horsepower Relation")

# The following lines produce modified boxplots of "mpg"
boxplot(mpg, 
        horizontal = F, 
        xlab = "MPG",
        col = 'purple')
hist(mpg,
     breaks=20,
     col='purple')

boxplot(mpg, 
        mpg[cylinders==8], 
        mpg[cylinders==6], 
        mpg[cylinders==5], 
        mpg[cylinders==4], 
        horizontal = F,
        col = 'pink',
        names = c("MPG","C8","C6","C5","C4"))

# OUTLIERS DETECTION INTERVAL:
# For mpg data with Cylinders 6.
MPG6 = mpg[cylinders==6]

Q6 = quantile(MPG6)
IQR6 = IQR(MPG6) 

OutLeft = Q6[2]-1.5*IQR6
OutRight = Q6[4]+1.5*IQR6

Interval = c(OutLeft,OutRight)
Interval

# How many observations are there
# above OutRight?
sum(MPG6 > OutRight)
# What are those values?
MPG6[MPG6 > OutRight]

# The following lines produce four relative
# frequency histograms for mpg just in one picture.
par(mfrow = c(2,2))
hist(mpg, freq = FALSE, breaks = 20, col = 'purple', xlab = "MPG of Cars", ylab = "Frequency", main = "Histogram")
hist(mpg[cylinders == 8], freq = FALSE, breaks = 20, col = 'purple', xlab = "MPG of Cars, C = 8", ylab = "Frequency", main = "Histogram")
hist(mpg[cylinders == 6], freq = FALSE, breaks = 20, col = 'purple', xlab = "MPG of Cars, C = 6", ylab = "Frequency", main = "Histogram")
hist(mpg[cylinders == 4], freq = FALSE, breaks = 20, col = 'purple', xlab = "MPG of Cars, C = 4", ylab = "Frequency", main = "Histogram")
par(mfrow = c(1,1))

# The following lines produce four relative
# frequency histograms for acceleration just in one picture.
par(mfrow = c(2,2))
hist(acceleration, freq = FALSE, breaks = 15, col = 'purple', xlab = "Acceleration of Cars", ylab = "Relative Freq.", main = "Histogram")
hist(acceleration[cylinders == 8], freq = FALSE, breaks = 20, col = 'purple', xlab = "Acceleration of Cars, C = 8", ylab = "Relative Freq.", main = "Histogram")
hist(acceleration[cylinders == 6], freq = FALSE, breaks = 20, col = 'purple', xlab = "Acceleration of Cars, C = 6", ylab = "Relative Freq.", main = "Histogram")
hist(acceleration[cylinders == 4], freq = FALSE, breaks = 20, col = 'purple', xlab = "Acceleration of Cars, C = 4", ylab = "Relative Freq.", main = "Histogram")
par(mfrow = c(1,1))

# How many cars are there having 4 cylinders.
sum(cylinders == 4)

# Find the name of a brand of the car having
# mpg bigger than 45.
name[mpg>45]
name[mpg<10]
name[(mpg>40) || (cylinders == 6)]

# Summary statistics.
mean(mpg)
median(mpg)
quantile(mpg)
IQR(mpg)
sd(mpg)
summary(mpg)

detach(Auto)

